const c="/react/assets/img/credit-card.svg";export{c};
