const a="/react/assets/img/viabo-pay.png";export{a as V};
