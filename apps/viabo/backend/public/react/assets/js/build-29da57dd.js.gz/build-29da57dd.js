import{O as a,U as o,V as s,W as t,X as e}from"./index-6aaca417.js";const n={renderer:a,...o,...s},r={...n,...t,...e};export{r as default};
