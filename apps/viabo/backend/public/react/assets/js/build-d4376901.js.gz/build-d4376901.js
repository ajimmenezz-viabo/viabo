import{r as t}from"./index-225b8590.js";function a(i,r){return t.isValidElement(i)&&r.indexOf(i.type.muiName)!==-1}export{a as i};
