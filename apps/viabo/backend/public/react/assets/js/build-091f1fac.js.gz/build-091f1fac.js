const s="/react/assets/img/mail.svg";export{s as m};
