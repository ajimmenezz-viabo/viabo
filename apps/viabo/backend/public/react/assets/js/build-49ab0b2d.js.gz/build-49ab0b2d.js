const s={GLOBAL_CARDS:"global-cards",MOVEMENTS:"master-movements"};export{s as D};
