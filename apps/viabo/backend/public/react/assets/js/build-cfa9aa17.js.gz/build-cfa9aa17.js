import{y as r,j as o}from"./index-b206e6bf.js";const a=r(o.jsx("path",{d:"M6.23 20.23 8 22l10-10L8 2 6.23 3.77 14.46 12z"}),"ArrowForwardIos");export{a as A};
