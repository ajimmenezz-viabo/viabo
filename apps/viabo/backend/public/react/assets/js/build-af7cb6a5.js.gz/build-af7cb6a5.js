import{t,j as s}from"./index-6d113efd.js";const o=t(s.jsx("path",{d:"M2.01 21 23 12 2.01 3 2 10l15 2-15 2z"}),"Send");export{o as S};
