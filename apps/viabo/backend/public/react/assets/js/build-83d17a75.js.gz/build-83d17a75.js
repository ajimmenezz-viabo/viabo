const a="/react/assets/img/viabo-card.png";export{a as V};
