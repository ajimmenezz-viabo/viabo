import{V as a,W as o,X as s,Y as t,$ as e}from"./index-1fae866e.js";const n={renderer:a,...o,...s},r={...n,...t,...e};export{r as default};
