const t="/react/assets/img/integracion-tecnologica.png";export{t as I};
