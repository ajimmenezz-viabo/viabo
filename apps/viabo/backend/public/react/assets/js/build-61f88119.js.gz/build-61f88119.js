import{r as t}from"./index-dce238d3.js";function a(i,r){return t.isValidElement(i)&&r.indexOf(i.type.muiName)!==-1}export{a as i};
